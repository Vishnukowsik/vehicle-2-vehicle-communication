from traffic_simulation import *

sim = Simulation()
sim.runSimulation()

